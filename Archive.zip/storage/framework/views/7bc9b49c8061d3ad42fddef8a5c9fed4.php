<ul class="account-nav">
    <li><a href="<?php echo e(route('user.index')); ?>" class="menu-link menu-link_us-s">Dashboard</a></li>
    <li><a href="<?php echo e(route('user.account.orders')); ?>" class="menu-link menu-link_us-s <?php echo e(Route::is('user.account.orders') ? 'menu-link_active':''); ?>">Orders</a></li>
    <li><a href="account-address.html" class="menu-link menu-link_us-s">Addresses</a></li>
    <li><a href="account-details.html" class="menu-link menu-link_us-s">Account Details</a></li>
    <li><a href="account-wishlist.html" class="menu-link menu-link_us-s">Wishlist</a></li>
    <form action="<?php echo e(route('logout')); ?>" method="post" id="logout-form">
        <?php echo csrf_field(); ?>
        <li><a href="<?php echo e(route('logout')); ?>" class=""
                onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                class="menu-link menu-link_us-s">Logout</a></li>
    </form>
</ul>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/EcoMarket/EcoMarket/resources/views/user/account-nav.blade.php ENDPATH**/ ?>